import React from 'react';
import {  Link } from 'react-router-dom';
import './topnav.css';
const topnav = () => {
    return(
        <nav className="navbar navbar-expand-lg  bg-dark">
        <ul>< Link to={'/'} className="navbar-brand label">Photo Gallery</ Link></ul>
        <ul>< Link to={'/favourite'} className="navbar-brand label">Favourites</ Link></ul>
        <div className="logout_btn" >
          <button className="btn logout my-2 my-sm-0" type="submit">Logout</button>
        </div>
        </nav>
    )
}
export default topnav;