import React,{Component} from 'react';
import './login.css';
class Login extends Component{

    state={
        username:"",
        password:""
    }

    componentWillMount(){

        let userDetail=[
            {
                username:'arshi',
                password:'arshi@123'
            },
            {
                username:'khan',
                password:'khan@123'
            }
        ]

        

        localStorage.setItem("user",JSON.stringify(userDetail));
        console.log(JSON.parse(localStorage.getItem('user')));
        
    }

    formHandler=(event)=>{
        let name=event.target.name;
        let value=event.target.value;
        this.setState({[name]:value})
        
    }
    mySubmitHandler=(event)=>{

        let username=this.state.username;
        let password=this.state.password;
        let user=JSON.parse(localStorage.getItem('user'));
        console.log("user:",user);
        let authenicated=user.map(u=>{
            if(this.state.username===u.username && this.state.password ===u.password)
            {
                return true;
            }

        })
        if (authenicated==true)
        alert("User Authenticated");
        else 
       alert("User not Authenticated");
       /*  if(username===localStorage.getItem('username') && password === localStorage.getItem('password'))
        {
            console.log("user authenicated");
        } */

    }

    render(){
        console.log(this.state.username);
        return(
            <div className="login"> 
            <form className="login-form" >
                    <div className="form-group">
                        <input className="form-control" 
                               type="text"  id="username" 
                               placeholder="Enter Username"
                               name="username"
                               onChange={this.formHandler}/>
                    </div>
                    <div className="form-group">
                        <input type="password" 
                                className="form-control" 
                                id="password" 
                                name="password"
                                placeholder="Password"
                                onChange={this.formHandler}/>
                    </div>
                   
                    <button type="submit" className="btn btn-primary" onClick={this.mySubmitHandler}>Submit</button>
                    </form>
            </div>
    
        )
    }
}

export default Login;